menu = document.querySelector('.menu i');
navbar = document.querySelector('.header .navbar');

menu.onclick=()=>{
    navbar.classList.toggle('active');
}